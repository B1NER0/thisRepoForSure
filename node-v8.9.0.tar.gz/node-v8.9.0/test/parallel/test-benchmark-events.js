'use strict';

require('../common');

const runBenchmark = require('../common/benchmark');

runBenchmark('events', ['n=1']);
